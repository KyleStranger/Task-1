﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KyleStranger.GADE6111.Task1
{
    class Goblin
    {
        int goblinHP = 10;
        int goblinDamage = 1;

        //public override ReturnMove()
       // {

       // }
    }
}
