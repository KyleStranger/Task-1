﻿using System;

namespace KyleStranger.GADE6111.Task1
{
    abstract class Enemy : Character
    {
        public Enemy(int tempHP, int tempmaxHP, int tempDamage, Tile[] tempVision, int tempx, int tempy) : base(tempHP, tempmaxHP, tempDamage, tempVision, tempx, tempy) { }

        public override string ToString()
        {

            string tempInfo = "";
            tempInfo += hp.ToString() + "\n";
            tempInfo += maxhp.ToString() + "\n";
            tempInfo += damage.ToString() + "\n";
            tempInfo += x.ToString() + "\n";
            tempInfo += y.ToString() + "\n";

            return tempInfo;
        }
    }
}


