﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KyleStranger.GADE6111.Task1
{
    class Map
    {
        Map = new char[10 , 10];
        int pY;
        int pX;


        void RedrawMap()
        {
            for (int y= 0; y< 10; y++)
            {
                for (int x = 0; x < 10; y++)
                {
                    if (x== pX && y == pY)
                    {
                        Map[y, x] = '0';
                    }
                    else
                    {
                        Map[y , x] = '.'
                    }
                }
            }
        }
    }
}
