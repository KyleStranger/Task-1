﻿using System;
using System.Net.Mail;

namespace KyleStranger.GADE6111.Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Enemy Barbarian = new Enemy(10, 100, 10, null, 0, 0);

            Console.WriteLine(Barbarian.ToString());
            Console.ReadLine();
        }
    }
}
